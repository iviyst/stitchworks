# Stitchworks on GitHub Pages: setup

Your link when it's live: **https://iviyst.github.io/stitchworks/**

## 1. Create the repo and turn on Pages (one time)

1. On GitHub, create a new public repository named `stitchworks`.
2. Click **Add file → Upload files** and drag in all 23 files from this zip at once (SETUP.md is optional). They are all flat files, so no folders are needed:
   - the game: `index.html`, `sw.js`, `manifest.webmanifest`
   - icons: `icon-180.png`, `icon-192.png`, `icon-512.png`, `icon-maskable-512.png`
   - Zippa: `zippa-model.txt` (his 3D model), `zippa-skin.jpg`, `zippa-mr.jpg` (his textures) and `zippa-scare.mp4` (his filmed jump scare)
   - art: `factory-keyart.jpg`, `wood.jpg`, `fabric.jpg`, and the 9 `grunge-*.jpg` texture files

   If a file is missing the game still runs: without the Zippa files he falls back to a simpler built-in model and the in-engine jump scare, and without the art files you get the older flat textures and no menu artwork.
3. Commit.
4. Go to **Settings → Pages**. Under *Build and deployment*, set Source to **Deploy from a branch**, Branch to **main**, and folder to **/ (root)**. Save.
5. After a minute or two, open https://iviyst.github.io/stitchworks/.

## 2. Set up Firebase (one time)

Accounts and Team Escape use your **stitchworks-e505c** Firebase project. The game is already pointed at it.

**Realtime Database rules.** Open the Firebase console → **Realtime Database** → **Rules**, replace everything with the contents of `database.rules.json` (also below), then **Publish**:

```json
{
  "rules": {
    "rooms": {
      "$room": {
        ".read": "auth != null && $room.matches(/^[A-Z]{6}$/)",
        ".write": "auth != null && data.child('meta/host').val() === auth.uid",
        "meta": {
          ".write": "auth != null && $room.matches(/^[A-Z]{6}$/) && (!data.exists() || data.child('host').val() === auth.uid) && newData.child('host').val() === auth.uid"
        },
        "players": {
          "$pid": {
            ".write": "auth != null && auth.uid === $pid && root.child('rooms/'+$room+'/meta').exists()",
            "n": {
              ".validate": "newData.isString() && newData.val().length <= 18"
            }
          }
        },
        "world": {
          ".write": "auth != null && root.child('rooms/'+$room+'/players/'+auth.uid).exists()"
        },
        "ev": {
          ".write": "auth != null && root.child('rooms/'+$room+'/players/'+auth.uid).exists()"
        }
      }
    },
    "users": {
      "$uid": {
        ".read": "auth != null && auth.uid === $uid",
        ".write": "auth != null && auth.uid === $uid",
        "name": {
          ".validate": "newData.isString() && newData.val().length <= 18"
        },
        "created": {
          ".validate": "newData.isNumber()"
        },
        "stats": {
          "$k": {
            ".validate": "newData.isNumber() && newData.val() >= 0"
          }
        },
        "$other": {
          ".validate": false
        }
      }
    }
  }
}
```

What these rules allow:

- Only signed-in players (guests count) can touch anything.
- Only the host can change a room's settings, run the monsters, or close the room.
- Each player can write only their own spot in a room.
- Shared progress and events can only be written by people actually in that room.
- Each player can read and write only their own profile, and profiles accept only a short name and numeric stats.

**Sign-in methods.** Go to **Authentication** → **Sign-in method** and turn on all three:

1. **Anonymous**: guests and Team Escape need this.
2. **Email/Password**
3. **Google**: pick a support email when it asks.

**Authorized domains.** Go to **Authentication** → **Settings** → **Authorized domains** → **Add domain** and add `iviyst.github.io`. Google sign-in won't work on your site without it.

If Team Escape shows *"The server refused access"*, the database rules are missing or have a typo. If the Account screen says a sign-in method "is not switched on", turn it on in **Sign-in method**.

## Security: the "possible secret detected" warning

GitHub and Google flag the `apiKey` in `index.html` because it looks like a Google API key. **A Firebase web key is not a password.** Google's own docs say it is safe to publish: it only tells the browser which Firebase project to talk to, and every website using Firebase ships one. What actually protects your data is the database rules above and the key restrictions below. Hiding the key isn't possible on a static site anyway, since every visitor's browser needs it.

Do these once:

1. **Restrict the key to your site.** Open https://console.cloud.google.com/apis/credentials and pick the **stitchworks-e505c** project. Open **Browser key (auto created by Firebase)**.
   - Under **Application restrictions**, choose **Websites** and add:
     - `https://iviyst.github.io/*`
     - `https://stitchworks-e505c.firebaseapp.com/*`
     - `http://localhost/*`, if you ever test locally
   - Under **API restrictions**, choose **Restrict key** and tick **Identity Toolkit API**, **Token Service API** and **Firebase Installations API**.
   - Click **Save**. It can take a few minutes to apply.

   A copied key then fails anywhere except your site.
2. **Publish the database rules** above. This is the part that actually locks the data down.
3. **Close the alert.** In the repo go to **Security → Secret scanning**, open the alert, and close it as **Won't fix**. If GitHub asks for a reason, write "Firebase web API key, public by design, restricted to iviyst.github.io".
4. **Old Syncwave key.** Earlier versions of `index.html` held your Syncwave project's key, and it stays in the repo's history after you upload the new file. Give that key the same website restriction in the **syncwave-83ac4** project, listing the sites Syncwave and Stickline run on, and close its alert the same way.
5. **Optional, App Check.** For more protection, turn on Firebase App Check with reCAPTCHA v3. Then only your real site can reach the database, even with the key. Send me the reCAPTCHA site key and I'll wire it in.

## Accounts

Tap **ACCOUNT** on the main menu. Players can stay guests or sign in with Google or an email and password. A guest who signs in keeps the same player, nothing is lost. Signed-in players keep their callsign and stats on every device:

- solo runs and escapes, plus their best escape time
- team runs and escapes
- times caught
- most dolls found

The callsign also fills in the Team Escape name box automatically.

## 3. Playing team escape

1. One player taps **TEAM ESCAPE**, enters a callsign (up to 18 characters), and taps **CREATE PRIVATE ROOM**.
2. That player shares the 6-letter room code, or taps **COPY INVITE** and sends the link (`.../stitchworks/#ABCDEF`). Opening the link goes straight to the join screen.
3. Friends enter the code, tap **JOIN**, then tap **READY UP**. Up to 5 players can be in a room.
4. The host picks a difficulty and taps **START EXPEDITION** once everyone is ready. A host on their own can start straight away. Someone who joins mid-run taps **READY UP** to drop in.

How a team run works:

- **Shared progress:** items, fuses, keys, code tags, unlocked doors, the map and journal pages are shared by the whole crew. When anyone picks something up, everyone has it.
- **Monsters:** they hunt every player. Teammates appear as guards in suits with name tags and flashlight beams.
- **Getting caught:** you go down on the floor where you were caught. A teammate who gets within 2 metres, with a clear line of sight, taps **USE** or the flashing **REVIVE** button to get you back up. While you're down, tap the screen to watch another teammate.
- **Pings:** tap **PING** to send *HELP / OVER HERE / RUN / FOUND SOMETHING*. Everyone sees your name, the room you're in, and a colored light beam where you're standing.
- **Winning and losing:** the run is won only when **every** player has escaped through the gate. It is lost when nobody is left inside who could revive the others.
- **The game doesn't pause** in team play. The pause menu still opens, but the factory keeps moving.
- **The host runs the monsters**, so the host should keep the game open and in front. If the host leaves, the room closes.

Solo Escape and Night Shift work exactly as before.

## Updating later

Upload the new files over the old ones. If players installed the game on their phones, also change `VERSION` at the top of `sw.js` (this release is `stitchworks-gh-v7`, so the next would be `stitchworks-gh-v8`) and upload it too, so their copy refreshes.

## Firebase usage

Each player sends about 10 small updates a second while playing. A typical 5-player, 20-minute run uses roughly 40–60 MB of Realtime Database download, so the free Spark plan's 10 GB a month covers a lot of play. Rooms delete themselves when the host leaves. Account profiles are tiny (a name and a few numbers).
